#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * 
 * @author: yim create time ${DATE}
 */
public enum ${NAME} {
}
